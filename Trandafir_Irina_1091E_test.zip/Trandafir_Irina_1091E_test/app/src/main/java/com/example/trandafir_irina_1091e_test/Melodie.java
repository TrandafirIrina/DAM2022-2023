package com.example.trandafir_irina_1091e_test;

import android.os.Parcel;
import android.os.Parcelable;

// clasa implementeaza Parcelable pentru ca obiectele de tipul acestei clase sa poata fii trimise
// intre activitati
public class Melodie implements Parcelable {
    private int id;
    private String numeSolist;
    private float durata;
    private Boolean ePeYoutube;

    public Melodie(int id, String numeSolist, float durata, Boolean ePeYoutube) {
        this.id = id;
        this.numeSolist = numeSolist;
        this.durata = durata;
        this.ePeYoutube = ePeYoutube;
    }

    protected Melodie(Parcel in) {
        id = in.readInt();
        numeSolist = in.readString();
        durata = in.readFloat();
        byte tmpEPeYoutube = in.readByte();
        ePeYoutube = tmpEPeYoutube == 0 ? null : tmpEPeYoutube == 1;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(numeSolist);
        dest.writeFloat(durata);
        dest.writeByte((byte) (ePeYoutube == null ? 0 : ePeYoutube ? 1 : 2));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Melodie> CREATOR = new Creator<Melodie>() {
        @Override
        public Melodie createFromParcel(Parcel in) {
            return new Melodie(in);
        }

        @Override
        public Melodie[] newArray(int size) {
            return new Melodie[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumeSolist() {
        return numeSolist;
    }

    public void setNumeSolist(String numeSolist) {
        this.numeSolist = numeSolist;
    }

    public float getDurata() {
        return durata;
    }

    public void setDurata(float durata) {
        this.durata = durata;
    }

    public Boolean getePeYoutube() {
        return ePeYoutube;
    }

    public void setePeYoutube(Boolean ePeYoutube) {
        this.ePeYoutube = ePeYoutube;
    }

    @Override
    public String toString() {
        return "Melodie{" +
                "id=" + id +
                ", numeSolist='" + numeSolist + '\'' +
                ", durata=" + durata +
                ", ePeYoutube=" + ePeYoutube +
                '}';
    }
}
