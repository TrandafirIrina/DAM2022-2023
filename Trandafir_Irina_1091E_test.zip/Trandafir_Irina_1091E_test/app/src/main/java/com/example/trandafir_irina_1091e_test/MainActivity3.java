package com.example.trandafir_irina_1091e_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initializez o lista de Melodii cu lista pasata prin Intent
        // getIntent() returneaza Intent-ul prin care s-a deschis activitatea curenta
        // cu getParcelableArrayListExtra obtinem lista din bundle-ul continut de intent
        List<Melodie> listaMelodii = new ArrayList<>(getIntent().
                getParcelableArrayListExtra("listaMelodii"));
        // Adapterul custom primeste contextul (obtinut prin this), codul resursei layout-ului custom,
        // si lista de melodii
        MelodieAdapter melodieAdapter = new MelodieAdapter(this,
                R.layout.layout_listview, listaMelodii);
        ListView listView = findViewById(R.id.trandafir_irina_lvMelodii);
        // Atasez adapterul controlului de tip ListView
        listView.setAdapter(melodieAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // De fiecare data cand dau click pe un item, va aparea un mesaj scurt (un toast)
                // in care este afisat obiectul de tip Melodie selectat
                Toast.makeText(getApplicationContext(), listaMelodii.get(i).toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                // cresterea duratei cu 10%
                listaMelodii.get(i).setDurata(listaMelodii.get(i).getDurata()*1.1f);
                // ca sa actualizeze in listview, trebuie ca adaptorul sa primeasca o notificare
                // in acest sens
                melodieAdapter.notifyDataSetChanged();
                return true;
            }
        });
    }
}