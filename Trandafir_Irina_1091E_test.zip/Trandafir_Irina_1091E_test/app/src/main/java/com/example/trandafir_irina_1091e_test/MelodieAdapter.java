package com.example.trandafir_irina_1091e_test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class MelodieAdapter extends BaseAdapter {
    // Am pus ca atribute, atributele pe care le primeste si un ArrayAdapter
    private Context context;
    private int resursa;
    private List<Melodie> listaMelodii;

    public MelodieAdapter(Context context, int resursa, List<Melodie> listaMelodii) {
        this.context = context;
        this.resursa = resursa;
        this.listaMelodii = listaMelodii;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public int getResursa() {
        return resursa;
    }

    public void setResursa(int resursa) {
        this.resursa = resursa;
    }

    public List<Melodie> getListaMelodii() {
        return listaMelodii;
    }

    public void setListaMelodii(List<Melodie> listaMelodii) {
        this.listaMelodii = listaMelodii;
    }

    @Override
    public String toString() {
        return "MelodieAdapter{" +
                "context=" + context +
                ", resursa=" + resursa +
                ", listaMelodii=" + listaMelodii +
                '}';
    }

    @Override
    public int getCount() {
        return listaMelodii.size();
    }

    @Override
    public Object getItem(int i) {
        if(i>=0 && i<=getCount())
            return listaMelodii.get(i);
        else return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        // Cu ajutorul metodei from a clasei abstracte LayoutInflator obtin LayoutInflator-ul contextului
        // curent (furnizat de atributul context)

        // Cu ajutorul acestuia voi crea view-urile corespunzatoare layout-ului custom, utilizand
        // metoda inflate
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        // Nu sunt sigura daca am inteles bine, dar viewGroup ar fii ListView-ul
        // iar valoarea false al celui de-al treilea parametru
        // ar insemna ca nu vrem sa atasam view-ul obtinut prin inflate ca si copil al listView-ului
        view = layoutInflater.inflate(resursa, viewGroup, false);

        // Obiectul de tip view contine acum o referinta pentru containerul in care sa afla toate
        // view-urile de tip TextView

        // Referintele pentru fiecare TextView in parte le obtin apeland
        // findViewById pe obiectul view
        TextView tvId = view.findViewById(R.id.trandafir_irina_tvId);
        TextView tvNume = view.findViewById(R.id.trandafir_irina_tvNume);
        TextView tvDurata = view.findViewById(R.id.trandafir_irina_tvDurata);
        TextView tvPeYtb = view.findViewById(R.id.trandafir_irina_tvEPeYtb);

        // Parametrul i al functiei getView reprezinta pozitia din listview (si din lista de melodii)
        // a elementului ce trebuie reprezentat utilizand layout-ul custom (pe ecran pot aparea
        // doar 4 elemente pe ecran la un moment dat, pentru a obtine celelalte elemente
        // trebuie sa dam scroll si se reapeleaza getView)
        Melodie melodie = listaMelodii.get(i);

        // Setez textul afisat de fiecare textview astfel incat sa contina valorile
        // atributelor obiectului de tip melodie
        tvId.setText(String.valueOf(melodie.getId()));
        tvNume.setText(melodie.getNumeSolist());
        tvDurata.setText(String.valueOf(melodie.getDurata()));
        tvPeYtb.setText(melodie.getePeYoutube().toString());

        // returnez view-ul (corespunzator unei linii din listview)
        // ce contine acum controalele de tip TextView cu textul modificat
        return view;
    }
}
