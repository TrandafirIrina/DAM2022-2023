package com.example.trandafir_irina_1091e_test;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Melodie> listaMelodii = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Identific referinta butonului Adauga si o atribui unei instante de Button
        Button btnAdauga = findViewById(R.id.trandafir_irina_btnAdauga);
        // Creez un Listener pentru evenimentul de on click cu ajutorul unei clase anonime
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Deoarece ma aflu in interiorul unei clase anonime, nu mai pot avea acces
                // la context prin this asa cum aveam in clasa MainActivity si atunci
                // contextul il obtin prin functia getApplicationContext().

                // Al doilea parametru al constructorului obiectului de tip Intent este clasa
                // activitatii pe care doresc sa o deschid prin apasarea butonului Adauga.
                Intent it = new Intent(getApplicationContext(), MainActivity2.class);
                // Apelez startActivityForResult() deoarece vreau ca cea de a doua activitate
                // sa imi intoarca un rezultat, si anume, obiectul de tip Melodie.

                // Cel de al doilea parametru al functiei este codul activitatii 2
                // astfel incat atunci cand ma intorc din activitatea 2 in activitatea 1, sa
                // stiu ca m-am intors din activitatea 2 si nu din alta activitate pe care as fi
                // putut sa o deschid din activitatea 1.
                startActivityForResult(it, 2);
            }
        });

        Button btnVizualizare = findViewById(R.id.trandafir_irina_btnVizualizare);
        btnVizualizare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getApplicationContext(), MainActivity3.class);
                // Creez un obiect de tip Bundle, care e precum un dictionar: perechi cheie-valoare
                Bundle bundle = new Bundle();
                // Pun in bundle listaMelodii convertita la un ArrayList de obiecte
                // de orice tip (? este precum un wildcard) atata timp cat "extind" Parcelable.

                // Parcelable este o interfata care poate fii implementata. Cuvantul extends
                // il foloseam pentru mostenirea unei clase, deci presupun ca <? extends Parcelable>
                // inseamna orice clasa anonima care implementeaza interfata Parcelable
                bundle.putParcelableArrayList("listaMelodii",
                        (ArrayList<? extends Parcelable>) listaMelodii);
                // Adaug bundle-ul in Intent pentru a il trimite in Activitatea 3
                it.putExtras(bundle);
                // Pentru ca vreau doar sa afisez obiectele din lista, pot apela startActivity
                // pentru ca nu vreau sa imi returneze un rezultat.

                // Nu am stiut daca se doreste salvarea duratelor modificate ale melodiilor
                // (atunci cand in activitatea 3 prin evenimentul de OnLongItemClick creste cu 10%
                // durata melodiilor) in activitatea 1. Daca trebuiau pastrate duratele modificate
                // ale melodiilor atunci ar fi trebuit sa returnez ca rezultat lista modificata
                startActivity(it);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) // Daca m-am intors in activitatea principala dupa ce am salvat melodia
            if(requestCode == 2) // Daca m-am intors in activitatea principala din activitatea 2
            {
                // Intent-ul primit ca parametru contine obiectul de tip Melodie
                Melodie melodie = data.getParcelableExtra("melodie");
                // Adaug melodia in lista de melodii
                listaMelodii.add(melodie);
            }
    }
}