package com.example.trandafir_irina_1091e_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button btnSalvare = findViewById(R.id.trandafir_irina_btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obtin referintele controalelor din activitatea 2 si le atribui
                // unor instante de obiecte corespunzatoare fiecarui control in parte
                EditText etId = findViewById(R.id.trandafir_irina_etId);
                EditText etNume = findViewById(R.id.trandafir_irina_etNume);
                EditText etDurata = findViewById(R.id.trandafir_irina_etDurata);
                Switch switchEPeYtb = findViewById(R.id.trandafir_irina_switchPeYtb);

                // Pun continutul fiecarui control intr-o variabila
                // Cu aceste variabile voi crea o instanta a unui obiect de tip Melodie
                int id = Integer.parseInt(etId.getText().toString());
                String nume = etNume.getText().toString();
                float durata = Float.parseFloat(etDurata.getText().toString());
                Boolean ePeYtb = switchEPeYtb.isChecked();


                // Creez un obiect de tip Melodie
                Melodie melodie = new Melodie(id, nume, durata, ePeYtb);
                // Il pun in Bundle
                Bundle bundle = new Bundle();
                bundle.putParcelable("melodie", melodie);
                Intent it = new Intent();
                // Adaug bundle-ul in intent
                it.putExtras(bundle);
                // Setez resultCode pe RESULT_OK ca sa stiu ca ma intorc in activitatea principala
                // dupa ce am reusit salvarea unui obiect de tip melodie si nu pentru ca am dat cancel
                // Totodata trimit si intent-ul care contine obiectul de tip Melodie
                setResult(RESULT_OK, it);
                // Cu finish() ma intorc in activitatea 1
                finish();
            }
        });
    }
}