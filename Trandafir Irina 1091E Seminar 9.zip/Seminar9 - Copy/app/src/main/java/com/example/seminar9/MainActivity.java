package com.example.seminar9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

//    	0YAvdg7rr0q7z8GGyJ25BPSgFVBfVszh

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void afiseazaTemperaturi(View view) {
        EditText et = findViewById(R.id.etOras);
        String oras = et.getText().toString();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://dataservice.accuweather.com/locations/v1/cities/search?apikey=0YAvdg7rr0q7z8GGyJ25BPSgFVBfVszh&q=" + oras);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    // conexiunea nu este secure, traficul este transmis in clar, nu este criptat
                    // textul respectiv
                    String JSON = "";
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        JSON = reader.lines().collect(Collectors.joining(System.lineSeparator()));
                    }

                    JSONArray array = new JSONArray(JSON);
                    JSONObject oras = array.getJSONObject(0);
                    String codOras = oras.getString("Key");
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            ExecutorService executor2 = Executors.newSingleThreadExecutor();
                            executor2.execute(new Runnable() {
                                @Override
                                public void run() {
                                    try{
                                        URL url2 = new URL("http://dataservice.accuweather.com/forecasts/v1/daily/1day/"+codOras+"?apikey=0YAvdg7rr0q7z8GGyJ25BPSgFVBfVszh&metric=true");
                                        HttpURLConnection httpURLConnection2 = (HttpURLConnection) url2.openConnection();
                                        InputStream inputStream2 = httpURLConnection2.getInputStream();
                                        String JSON2 = "";
                                        BufferedReader reader2 = new BufferedReader(new InputStreamReader(inputStream2));
                                        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                                        {
                                            JSON2 = reader2.lines().collect(Collectors.joining(System.lineSeparator()));
                                        }

                                        JSONObject obiect = new JSONObject(JSON2);
                                        JSONArray array2 = obiect.getJSONArray("DailyForecasts");
                                        JSONObject jsonObject = array2.getJSONObject(0);
                                        JSONObject temperatura = jsonObject.getJSONObject("Temperature");
                                        JSONObject minim = temperatura.getJSONObject("Minimum");
                                        String valMinim = minim.getString("Value");
                                        JSONObject maxim = temperatura.getJSONObject("Maximum");
                                        String valMax = maxim.getString("Value");
                                        Log.w("temperatura", temperatura.toString());
                                         handler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                TextView textView = findViewById(R.id.textView);
                                                textView.setText(valMinim+", "+valMax);
                                            }
                                        });
                                    } catch (MalformedURLException e) {
                                        e.printStackTrace();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                        }
                    });
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}